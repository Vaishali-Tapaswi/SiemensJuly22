package main

import (
    "fmt"
    "strconv"
)

type Point2d struct {
    x int
    y int
}

type Point3d struct {
    x, y, z int
}

func (p Point2d) Display() string {
    str := "Point Details[x = " + strconv.Itoa(p.x) + " , y = " + strconv.Itoa(p.y) + "]"
    return str
}

func (p Point3d) Display() string {
    str := "Point Details[x = " + strconv.Itoa(p.x) + " , y = " + strconv.Itoa(p.y) + " , z = " + strconv.Itoa(p.z) + "]"
    return str
}

type Plot interface {
    Display() string
}

func main() {
    var plot Plot
    point2d := Point2d{2, 3}
    plot = point2d
	fmt.Println(plot.Display())
	point3d :=  Point3d{2, 3,3}
	var plot1 Plot = point3d
    fmt.Println(plot1.Display())

}