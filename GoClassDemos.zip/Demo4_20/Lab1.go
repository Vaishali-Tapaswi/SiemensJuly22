package main

import "fmt"
import "strconv"

type Emp struct {
	empno int
	ename string
}
func (e Emp) Convert() string {
	str :="Emp Details[Empno = ", strconv.Itoa(e.empno)+ " , Name = " + e.ename +"]" ;
	return str
}

type Tostr interface {
	Convert() string 
}


func main(){
	var a Tostr;
	e:= Emp{10,"aaa"}
	a = e
	fmt.Println(e.Convert())
	fmt.Println(a.Convert())
}


