package main

import(
	"fmt"
	"net/http"
	"io/ioutil"
)

func main(){
	//func (c *Client) Get(url string) (resp *Response, err error)
	client := http.Client{}
	resp, err := client.Get("https://reqres.in/api/users/2")
	fmt.Println("resp = ", resp)
	fmt.Println("err  =  ", err)
	fmt.Println("RespBody ", resp.Body)
	content, _ := ioutil.ReadAll(resp.Body)
	fmt.Println("Content = ", string(content))
	
 }

