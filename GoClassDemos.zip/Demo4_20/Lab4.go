package main

import (
	"fmt"
	"io"
	"log"
	"net/http"
)

func main() {
	indexPageHandler := func(w http.ResponseWriter, req *http.Request) {
		io.WriteString(w, "<h1>Index Page</h1>")
	}
	page1Handler := func(w http.ResponseWriter, req *http.Request) {
		io.WriteString(w, "<h1>Page One</h1>")
	}
	http.HandleFunc("/", indexPageHandler)
	http.HandleFunc("/page1", page1Handler)
	fmt.Println("Sever starting on port 8080.....")
	log.Fatal(http.ListenAndServe(":8080", nil))
}
