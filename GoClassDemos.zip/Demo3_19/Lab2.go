package main

import(
	"fmt"
)

func main(){
	primes := [2]int{2, 3}
	fmt.Println("Primes Details " , primes)
	sl1:= primes[:2]
	fmt.Println("Sl1 Details " , sl1 , "Length = ", len(sl1)," , Capacity =  " , cap(sl1))
	sl1 = append(sl1,0)
	fmt.Println("Sl1 Details " , sl1 , "Length = ", len(sl1)," , Capacity =  " , cap(sl1))

	sl1 = append(sl1,1)
	fmt.Println("Sl1 Details " , sl1 , "Length = ", len(sl1)," , Capacity =  " , cap(sl1))

}