package main

import (
    "fmt"
)

type Student struct {
    name string
    marks int
}

func main(){
    var num int
    fmt.Println("Enter number: ")
    fmt.Scanln(&num)
    a := make([]Student, num)

    for i:=0;i<num;i++{
        fmt.Println("Enter name and marks: ")
        fmt.Scanln(&a[i].name,&a[i].marks)

    }


	for i, v := range a {
		fmt.Printf("i = " , i, "Value = ", v)
	}

    

}