package main

import(
	"fmt"
)

func main(){
	primes := [6]int{2, 3, 5, 7, 11, 13}
	fmt.Println(primes)
	fmt.Println("\n\n")
	for i:=0;i<len(primes);i++{
		fmt.Println("------",primes[i])
	}
	primes[6]=333
	fmt.Println("\n")
	fmt.Println(primes)
	fmt.Println("\n")
	
}