package main

import "fmt"

func main(){
	var m map[string]int;
	m = make(map[string]int)
	m["a"]=100
	m["b"]=200
	m["a"]=300
	
	for i, v := range m {
		fmt.Println("i = " , i, "Value = ", v)
	}
	element,ok := m["a"]
	fmt.Println("Value of element is " , element, " ok value is " , ok)
	element,ok = m["d"]
	fmt.Println("Value of element is " , element, " ok value is " , ok)

	delete(m,"a")
	fmt.Println("After Deletion")
	for i, v := range m {
		fmt.Println("i = " , i, "Value = ", v)
	}


}