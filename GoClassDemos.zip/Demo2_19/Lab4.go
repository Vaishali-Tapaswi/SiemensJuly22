package main

import (
	"fmt"
)
func main(){
	i := 10
	fmt.Println(i)
	fmt.Println(&i)
	x := i
	i = 1000
	fmt.Println(x)
	fmt.Println(&x)
}