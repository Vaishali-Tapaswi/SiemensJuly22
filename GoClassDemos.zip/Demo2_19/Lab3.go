package main

import (
	"fmt"
)

func main(){

	fmt.Println("Hello ")
	fmt.Println("1")
	fmt.Println("invoking test with i = 10")
	test(10)
	fmt.Println("2")
	 str := "One"
	defer test1(str)
	str = "Two"
	test1(str)
	fmt.Println("3")
	fmt.Println("4")
	
}

func test(  i int){
	fmt.Println("\tline1 of test ")
	fmt.Println("\tin test " , i)
	fmt.Println("\tline3 of test ")
}


func test1( str string){
	fmt.Println("\tin test1 ", str)
}

