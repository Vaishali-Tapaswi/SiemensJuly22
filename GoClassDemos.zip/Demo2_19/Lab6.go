package main
import (
	"fmt"
)

type Point struct {
	x int
	y int
}

func main(){
	p1 := Point{20,50}
	fmt.Println("Original Point " , p1)
	shift(&p1, 1,3)
	fmt.Println("After Shift " , p1)
	p2 := Point{11,22}
	p3:= add(p1,p2)
	fmt.Println("P3 " , p3)
	
}

func shift(pint *Point, x, y int)  {
    pint.x += x
	pint.y+=y
	fmt.Println("In shift ", pint)
}


func add(p1, p2 Point ) (Point) {
   return Point{p1.x+p2.x, p1.y+p2.y}
}
