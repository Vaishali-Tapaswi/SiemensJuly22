package main
import (
	"fmt"
)

type Point struct {
	x int
	y int
}

func main(){
	p1 := Point{20,50}
	fmt.Println("Original Point " , p1)
	p1.shift( 1,3)
	fmt.Println("After Shift " , p1)

	
}

func (pint *Point) shift(x, y int)  {
    pint.x += x
	pint.y+=y
	fmt.Println("In shift ", pint)
}
