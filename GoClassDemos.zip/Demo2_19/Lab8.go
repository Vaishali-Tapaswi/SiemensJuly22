package main
import (
	"fmt"
)

type Emp struct {
    eno    int
	ename  string
    salary float64
}

func (emp Emp) printt() {
    fmt.Println(emp.ename)
    fmt.Println(emp.eno)
    fmt.Println(emp.salary)
}

func (pint *Emp) incr(page float64) {
    pint.salary += ((page / 100) * (pint.salary))
}

func main() {

    p2 := Emp{1,"AAA", 70000}
    p2.printt()
	p2.incr(10)
    fmt.Println("New Salary ", p2.salary)

}