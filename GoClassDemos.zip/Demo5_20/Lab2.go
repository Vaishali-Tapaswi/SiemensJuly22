package main

import (
	"encoding/json"
	"fmt"
)

type Emp struct {
	Empno int `json:"employeenumber"`
	Ename string `json:"employeename"`
}

func main() {
	e1 := Emp{10, "SSimple"}
	convertedbarr, err := json.Marshal(e1)
	if err != nil {
		fmt.Println("Error ", err)
	} else {
		fmt.Println("Converted String ", string(convertedbarr))
	}
	str := "{\"employeenumber\":100,\"employeename\":\"Siemens\"}"
	var emp Emp
    json.Unmarshal([]byte(str), &emp)
    fmt.Println(emp.Empno)
    fmt.Println(emp.Ename)
}
