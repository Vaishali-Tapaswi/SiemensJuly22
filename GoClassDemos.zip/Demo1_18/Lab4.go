package main

import (
	"fmt"
)

func main(){
	x,y:=0,0
	fmt.Print("Enter Number 1 : ")
	fmt.Scanln(&x)
	fmt.Print("ENter Number 2 : ")
	fmt.Scanln(&y)
	hello()
/*	sum :=add(x,y)
	sub :=sub(x,y)
	fmt.Println("Sum = " , sum)
	fmt.Println("Subtraction = " , sub)
*/
	sum, sub := calc(x,y)
	fmt.Println("Sum = " , sum)
	fmt.Println("Subtraction = " , sub)
}
func hello(){
	fmt.Println("Hello Function invoked ..")
}

func calc(x int,y int)  (int,int)  {
	fmt.Println("Calc invoked with " , x, y)
	return x+y, x-y
}
/*
func add(x int,y int)  int  {
	fmt.Println("Add invoked with " , x, y)
	return x+y
}

func sub(x int,y int)  int  {
	fmt.Println("Sub invoked with " , x, y)
	return x-y
}
*/