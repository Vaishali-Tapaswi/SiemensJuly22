package main

import "fmt"
//main.main with no arguments and no return values
func main() {
	fmt.Println("Hello Worlds !!")

}
