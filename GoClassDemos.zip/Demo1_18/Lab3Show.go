package main

import "fmt"

func main() {
// variable Declaration and Initialization	
 // var name string
//	var age int
//	var name, age = "aa",3
	name,age := "",0  // Infer
    fmt.Println("Enter your name")
    fmt.Scanln(&name)
    fmt.Println("Enter your age")
    fmt.Scanln(&age)
    fmt.Println("Name : =", name)
    fmt.Println("Age : =", age)
    if age > 18 {
        fmt.Println("Major")
    } else {
        fmt.Println("Minor")
    }
}
