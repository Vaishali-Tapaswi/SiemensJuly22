package main

import "fmt"

func main(){
	name := "abc"
	fmt.Println("Name before scanln is " , name)
	fmt.Print("Enter your Name : ")

/*	count, _ := fmt.Scanln(&name)
	fmt.Println("Count  = " , count)
*/
	fmt.Scanln(&name)
	fmt.Println("Name after scanln is " , name)

}
