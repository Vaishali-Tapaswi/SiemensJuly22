package main

import (
	"fmt"
	"my"
)

func main(){
	x,y:=0,0
	fmt.Print("Enter Number 1 : ")
	fmt.Scanln(&x)
	fmt.Print("Enter Number 2 : ")
	fmt.Scanln(&y)
	my.Hello()
	sum :=my.Add(x,y)
	sub :=my.Sub(x,y)
	fmt.Println("Sum = " , sum)
	fmt.Println("Subtraction = " , sub)
}
