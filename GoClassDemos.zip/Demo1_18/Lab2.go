package main

import (
	"fmt"
	"os"
)

func main() {
	fmt.Println("Hello", "World", 1)
	x := 10
	fmt.Println("Value of x = ", x)
	x = 20
	fmt.Println("Value of x = ", x)
	/*	hostname, err := os.Hostname()
		if err == nil {
			fmt.Println("Host Name = ", hostname)
		} else {
			fmt.Println("Error ", err)
		}
	*/
	hostname, _ := os.Hostname()
	fmt.Println("Host Name = ", hostname)
}
