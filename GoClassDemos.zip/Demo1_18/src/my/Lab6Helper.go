package my
import "fmt"
func Hello(){
	fmt.Println("Hello Function invoked ..")
}

func Add(x int,y int)  int  {
	fmt.Println("Add invoked with " , x, y)
	return x+y
}

func Sub(x int,y int)  int  {
	fmt.Println("Sub invoked with " , x, y)
	return x-y
}
