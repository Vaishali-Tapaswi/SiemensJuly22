package main

import (
    "fmt"
    "sort"
	"os"
	"strconv"
)

func main(){
    
	fmt.Println(os.Args)
    count,_ := strconv.Atoi(os.Args[1])
	fmt.Println(count)

    marks := make([]int,count)
    fmt.Println("Enter numbers into array: ")
    for i:=0;i<count;i++{
        fmt.Scanln(&marks[i])
    }
    sort.Ints(marks)
    fmt.Println("Marks: ", marks)
}