package main
import "testing"
//import "fmt"
func TestAdd(t *testing.T) {
    got := add(10,40)
    if got != 50 {
        t.Errorf("add(10,40) = %d; want 50", got)
    }
}
func TestDivide1(t *testing.T) {
    got := divide("300", "50")
    if got != 6 {
        t.Errorf("divide('300', '50') = %d; want 6", got)
    }
}
// x = divide("x","50"),
func TestDivide2(t *testing.T) {
    got := divide("x", "50")
    if got != 0 {
        t.Errorf("divide('x', '50') = %d; want 0", got)
    }
}

//x = divide("50","0")
func TestDivide3(t *testing.T) {
    got := divide("300", "0")
	if got != 0 {
        t.Errorf("divide('300', '50') = %d; want 0", got)
    }
}

