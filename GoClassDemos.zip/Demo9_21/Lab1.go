package main

import (
	"fmt"
	"strconv"
)
func add(x, y int) int{
	return x+y
}

func divide(x, y string) int{
	no1, _ := strconv.Atoi(x)
	no2, _ := strconv.Atoi(y)
	if no2 == 0 {
		return 0
	}
	return no1/no2
}

func main(){
	x := add(30,50)
	fmt.Println("Sum  = ", x)
	x = divide("300","50")
	fmt.Println("Divide of 300 and 50  = ", x)
	x = divide("x","50")
	fmt.Println("Divide of x and 50  = ", x)
	x = divide("50","0")
	fmt.Println("Divide of 50 and 0  = ", x)
	
}