package main
import "testing"

func TestDivide1(t *testing.T) {
    got,_ := divide("300", "50")
    if got != 6 {
        t.Errorf("divide('300', '50') = %d; want 6", got)
    }
}
func TestDivide2(t *testing.T) {
    got,_ := divide("x", "50")
    if got != 0 {
        t.Errorf("divide('x', '50') = %d; want 0", got)
    }
}

func TestDivide3(t *testing.T) {
    _, err := divide("300", "0")
	if err == nil {
        t.Errorf("divide('300', '0') should have thrown error")
    }
}

