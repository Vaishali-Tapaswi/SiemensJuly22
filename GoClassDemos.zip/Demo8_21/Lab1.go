package main

import (
	"fmt"
	"database/sql"
	_ "github.com/go-sql-driver/mysql"
	"log"
)
type Emp struct {
    empno int
	ename string
	salary int
}



func main() {
	db, err := sql.Open("mysql", "admin:MyPassword@tcp(db.cgx7wslwcmx7.us-east-1.rds.amazonaws.com:3306)/demo")
	if err != nil {
		fmt.Println("Error for Open  = ", err)
		panic(err)
	} 
	fmt.Println("Got Connection", db)
	
/*	rows, err1 := db.Query("insert into emp values (22,'BBB',22000)")
	if err1 != nil {
		fmt.Println("Error for insert  = ", err1)
	} else {
		fmt.Println("Inserted ", rows)
	}
*/
	res, err := db.Query("SELECT * FROM emp")

    defer res.Close()

    if err != nil {
        log.Fatal(err)
    }

    for res.Next() {

        var emp1 Emp
        res.Scan(&emp1.empno, &emp1.ename, &emp1.salary)
	    fmt.Println(emp1)
    }
}
/*
1. Create - Insert
2. Delete 
3. Update 
4. Retrive - Show all records 
*/
//create table emp (empno numeric(2) primary key, ename varchar(20), salary numeric(9))