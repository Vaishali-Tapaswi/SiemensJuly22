package main

import "fmt"

func main() {
	go print(1,100,"--")
	print(101,200,"xx")
    x:=0
	fmt.Scanln(&x)
}

func print(start, end int, flag string){
	for i:=start;i<=end;i++{
		fmt.Print(flag ,"  ",i,"  ")
	}
}