package main
 
import (
    "fmt"
    "time"
	"math/rand"
)
var finalmenu = ""
func main() {
    
    go print("macd")
    go print("pizza")
    go print( "taco")
 
    x := 0
    fmt.Scanln(&x)
	fmt.Println("Final Choice is " , finalmenu)
}
 
func print(flag string) {
    for i := 0; i <= 1000  && finalmenu == ""; i++ {
        fmt.Print(flag ," ")
		time.Sleep(time.Duration(rand.Intn(10))*time.Millisecond)
    }
	if finalmenu=="" {
		finalmenu = flag
		fmt.Println("\n\nFor Loop Over for " , flag + "\n\n")

	}
}