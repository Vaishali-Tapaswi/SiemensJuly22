package main

import (
	"fmt"
	"strconv"
	"time"
)

func main() {
	c := make(chan string, 10)
	fmt.Println("Before Reader")
	go reader(c)
	fmt.Println("After REader")
	go writer("str", c)
	x := 0
	fmt.Scanln(&x)
}
func writer(str string, c chan string) {
	for i := 1; i <= 5; i++ {
		fmt.Println("#########in count ", i)
		c <- str + strconv.Itoa(i)
		time.Sleep(time.Millisecond * 100)
	}
}

func reader(ch chan string) {
	fmt.Println("in Reader...")

	for msg := range ch {
		fmt.Println("in reader ", msg)
		time.Sleep(time.Millisecond *10)
	}
	fmt.Println("After Reader ...")
}
