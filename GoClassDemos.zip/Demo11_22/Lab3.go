package main

import (
	"fmt"
	"net/http"
	"io"
)
func main(){
resp, err := http.Get("https://5a7l2s4vra.execute-api.us-east-1.amazonaws.com/default/demo1")
if err != nil {
	// handle error
}
defer resp.Body.Close()
body, err := io.ReadAll(resp.Body)
fmt.Println(string(body))
}