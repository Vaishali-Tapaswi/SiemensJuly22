package main

import (
	"fmt"
	"sync"
//	"time"
)
var sum = 0

func inc(mu *sync.Mutex){
	mu.Lock()
	sum++
	fmt.Println("Inc invoked " , sum)
	mu.Unlock()
}

func main() {
	mu := sync.Mutex{}
	for i := 0; i < 500; i++ {
		go inc(&mu )
	}
	x :=0
	fmt.Scanln(&x)
	fmt.Println("Last line of Main Sum = " , sum)
}
